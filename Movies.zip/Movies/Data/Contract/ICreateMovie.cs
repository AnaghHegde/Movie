﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Contract
{
    interface ICreateMovie
    {
        void CreateMovies(Movie movie);
    }
}
