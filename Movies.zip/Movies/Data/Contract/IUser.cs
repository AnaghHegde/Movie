﻿using Movies.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies
{
    public interface IUser
    {
        public void CreateUser(User user);
    }
}
