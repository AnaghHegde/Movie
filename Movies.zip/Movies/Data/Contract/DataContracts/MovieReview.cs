﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Contract
{
    public class MovieReview
    {

        public string UserName { get; set; }

        public int Rating { get; set; }

        public bool IsCritic { get; set; } = false;

        public int Year { get; set; } = DateTime.Now.Year;
    }
}
