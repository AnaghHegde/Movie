﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Contract
{
    public class Movie
    {
        public string MovieName { get; set; }

        public string Genre { get; set; }

        public int Year { get; set; }

        public int CriticCount { get; set; } = 0;
    }
}
