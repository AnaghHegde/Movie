﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Contract
{
    public class User
    {
        public String UserName { get; set; }

        public String UserType { get; set; } = "Viewer";

        public int RatingsCount { get; set; } = 0;
    }
}
