﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Contract
{
    public interface IMovieReview
    {
        void Addreview(String movieName, MovieReview movieReview);

        void CreateMovies(Movie movie);

        int GetAverage(String movieName);

        int GetAverageByYear(String movieName, int year);

        void GetTopMoviesByCritic(String genre, int limit);
    }
}
