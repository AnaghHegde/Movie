﻿using Movies.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Query
{
    public class CreateMoviesQuery
    {

        public void CreateMovie(Movie movie)
        {
            if (Storage.MoviesList.ContainsKey(movie.MovieName))
            {
                //ToDo move the error message to a res file or const class
                Console.WriteLine("Moview Already Exists");
            }
            else
            {
                Storage.MoviesList[movie.MovieName] = movie;
                //Console.WriteLine(Storage.MoviesList[movie.MovieName].MovieName);
            }
            
        }
    }
}
