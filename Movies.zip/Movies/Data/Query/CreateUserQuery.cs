﻿using Movies.Core;
using Movies.Data.Contract;
using System;

namespace Movies.Data.Query
{
    public class CreateUserQuery
    {
        public void AddUser(User user)
        {
            if(Storage.UserList.ContainsKey(user.UserName))
            {
                //TODO - Move the hardcoded string to a const class or res file
                Console.WriteLine("Error : ------------------  User Already Exists in the system");
            }
            else
            {
                Storage.UserList[user.UserName] = user;
                //Console.WriteLine("User created");
            }
        }

    }
}
