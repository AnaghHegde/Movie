﻿using Movies.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Query
{
    public class GetAverageReviewScoreQuery
    {
        public int GetAverageByYear(String movieName, int year)
        {
            if (Storage.MovieReviews.ContainsKey(movieName))
            {
                int count = 0, avg = 0;
                foreach (var review in Storage.MovieReviews[movieName])
                {
                    if (review.Year == year)
                    {
                        avg += review.IsCritic ? review.Rating * 2 : review.Rating;
                        count++;
                    }
                }
                avg = avg >0 ?  avg / count : avg;
                return avg > 10 ? 10 : avg;
            }
            else
            {
                throw new System.Exception("\nNo reviews exists for the moview");
            }
            
        }

        public int GetAverage(String movieName)
        {
            int count = 0, avg = 0;
            if(Storage.MovieReviews.ContainsKey(movieName))
            {
                foreach (var review in Storage.MovieReviews[movieName])
                {
                    avg += review.IsCritic ? review.Rating * 2 : review.Rating;
                    count++;
                }
                avg = avg > 0 ? avg / count : avg;
                return avg > 10 ? 10 : avg;
            }
            else
            {
                throw new System.Exception("\nNo reviews exists for the moview");
            }
        }
    }
}
