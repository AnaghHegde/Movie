﻿using Movies.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Query
{
    public class ReviewMovieQuery
    {
        public void Review(String movieName, MovieReview movieReview)
        {
            
            if(IsMovieExists(movieName) && IsNotReviewed(movieName, movieReview.UserName) && IsValidUser(movieReview.UserName) && IsValidRating(movieReview.Rating))
            {
                
                if (Storage.UserList[movieReview.UserName].RatingsCount > 2)
                {
                    if (Storage.UserList[movieReview.UserName].RatingsCount == 6)
                    {
                        Console.WriteLine("\nUser : " + movieReview.UserName + " is promoted to Expert User!!!!");
                        Storage.UserList[movieReview.UserName].UserType = "Expert";
                    }

                    if (Storage.UserList[movieReview.UserName].RatingsCount == 9)
                    {
                        Console.WriteLine("\nUser : " + movieReview.UserName + " is promoted to Admin User!!!!");
                        Storage.UserList[movieReview.UserName].UserType = "Admin";
                    }
                    Storage.UserList[movieReview.UserName].RatingsCount += 1;
                    Storage.MoviesList[movieName].CriticCount += 1;
                    movieReview.IsCritic = true;

                }
                else
                {
                    if (Storage.UserList[movieReview.UserName].RatingsCount == 2)
                    {
                        Storage.UserList[movieReview.UserName].RatingsCount += 1;
                        Storage.UserList[movieReview.UserName].UserType = "Critic";
                        Storage.MoviesList[movieName].CriticCount += 1;
                        movieReview.IsCritic = true;
                        Console.WriteLine("\nUser : " + movieReview.UserName + " is promoted to Critic User!!!!");
                    }
                    else
                    {
                        Storage.UserList[movieReview.UserName].RatingsCount += 1;
                    }
                }
                
                Storage.MovieReviews[movieName].Add(movieReview);
            }
        }

        private bool IsMovieExists(String name)
        {
            if (Storage.MoviesList.ContainsKey(name))
            {
                Movie movie = Storage.MoviesList[name];
                if(movie.Year < DateTime.Now.Year)
                {
                    return true;
                }
            }
            Console.WriteLine("\nError : Invalid Movie :- " + name+". You cannot review this movie as its not releases yet.");
            return false;
        }

        private bool IsNotReviewed(String name, String userName)
        {
            if (!Storage.MovieReviews.ContainsKey(name))
            {
                Storage.MovieReviews[name] = new List<MovieReview>();
                return true;
            }
            else
            {
                List<MovieReview> reviews = Storage.MovieReviews[name];
                foreach(MovieReview review in reviews)
                {
                    if (review.UserName.Equals(userName))
                    {
                        Console.WriteLine("\nError : Movie :- " + name + " " + "is already reviewed. Multiple reviews not allowed for user :-" + userName);
                        return false;
                    }
                }
            }
            return true;
        }

        private bool IsValidUser(String userName)
        {
            if (Storage.UserList.ContainsKey(userName))
            {
                return true;
            }
            Console.WriteLine("\nError : Invalid User");
            return false;
        }

        private bool IsValidRating(int rating)
        {
            if(rating<= 10)
            {
                return true;
            }
            Console.WriteLine("\nError : Invalid Rating. Please chose a number from 0 - 10");
            return false;
        }
    }
}
