﻿using Movies.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Query
{
    public class GetTopMoviesQuery
    {
        public void TopMoviesByCritic(String genre, int limit)
        {
            List<String> movies = new List<string>();
            foreach(KeyValuePair<String, Movie> movie in Storage.MoviesList)
            {
                if(movie.Value.Genre.Equals(genre))
                {
                    movies.Add(movie.Value.CriticCount + movie.Value.MovieName);
                }
            }
            movies.Sort();
            if(movies.Count == 0)
            {
                Console.WriteLine("\nNo movies are there in the Genre ::: " + genre);
            }
            Console.WriteLine("\nTop movies in the Genre ::: "+genre);
            String[] res = movies.ToArray();
            int j = 0;
            for(int i = res.Length-1;i>=0 && j<= limit; i--)
            {
                Console.WriteLine(res[i].Substring(1));
                j++;
            }
            
        }
    }
}
