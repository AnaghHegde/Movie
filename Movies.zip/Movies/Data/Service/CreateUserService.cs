﻿using Movies.Data.Contract;
using Movies.Data.Query;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Service
{
    public class CreateUserService : IUser
    {
        public void CreateUser(User user)
        {
            CreateUserQuery createUserQuery = new CreateUserQuery();
            createUserQuery.AddUser(user);
        }
    }
}
