﻿using Movies.Data.Contract;
using Movies.Data.Query;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data.Service
{
    public class MovieService : IMovieReview
    {
        public void Addreview(String movieName, MovieReview movieReview)
        {
            ReviewMovieQuery reviewMovieQuery = new ReviewMovieQuery();
            reviewMovieQuery.Review(movieName, movieReview);
        }

        public void CreateMovies(Movie movie)
        {
            CreateMoviesQuery createMoviesQuery = new CreateMoviesQuery();
            createMoviesQuery.CreateMovie(movie);
        }

        public int GetAverage(string movieName)
        {
            GetAverageReviewScoreQuery getAverage = new GetAverageReviewScoreQuery();
            return getAverage.GetAverage(movieName);
        }

        public int GetAverageByYear(String movieName, int year)
        {
            GetAverageReviewScoreQuery getAverage = new GetAverageReviewScoreQuery();
            return getAverage.GetAverageByYear(movieName, year);
        }

        public void GetTopMoviesByCritic(String genre, int limit)
        {
            GetTopMoviesQuery getTopMoviesQuery = new GetTopMoviesQuery();
            getTopMoviesQuery.TopMoviesByCritic(genre, limit);
        }
    }
}
