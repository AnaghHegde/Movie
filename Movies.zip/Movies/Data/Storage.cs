﻿using Movies.Data.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Data
{
    public class Storage
    {
        //public static List<User> UserList { get; set; }

        public static Dictionary<String, User> UserList { get; set; }

        public static Dictionary<String, Movie> MoviesList { get; set; }

        public static Dictionary<String, List<MovieReview>> MovieReviews {get; set;}

        public Storage()
        {
            UserList =  new Dictionary<string, User>();
            MoviesList = new Dictionary<string, Movie>();
            MovieReviews = new Dictionary<string, List<MovieReview>>();
        }
    }
}
