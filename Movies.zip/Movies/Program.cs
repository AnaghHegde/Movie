﻿using Movies.Data;
using Movies.Data.Contract;
using Movies.Data.Service;
using Movies.Logger;
using System;
using System.IO;

namespace Movies
{
    public class Program
    {
        
        public static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Inside");
                Storage storage = new Storage();
                Run run = new Run();
                run.CreateUser("SRK");
                run.CreateUser("Salman");
                run.CreateUser("Deepika");

                run.CreateMovie("Don",2020,"Action");
                run.CreateMovie("Tiger", 2008, "Drama");
                run.CreateMovie("Padmavat", 2006, "Comedy");
                run.CreateMovie("LunchBox", 2022, "Drama");
                run.CreateMovie("Guru", 2006, "Drama");
                run.CreateMovie("Metro", 2006, "Romance");

                run.AddReview("SRK","Don",2);
                run.AddReview("SRK", "Padmavat", 8);
                run.AddReview("Salman", "Don", 5);
                run.AddReview("Deepika", "Don", 9);
                run.AddReview("Deepika", "Guru", 6);
                run.AddReview("SRK", "Don", 10);
                run.AddReview("Deepika", "LunchBox", 5);
                run.AddReview("SRK", "Metro", 7);

                run.GetTopMovies("Drama", 5);

                run.GetAverageScore("Don");
                run.GetAverageScoreByYear("Don", 2021);
            }
            catch (Exception e)
            {
                ExceptionLog.Log(e);
            }

        }
    }

    public class Run
    {
        private MovieService _movieService;
        private CreateUserService _createUserService;

        public Run()
        {
            _movieService = new MovieService();
            _createUserService = new CreateUserService();
        }

        public void CreateUser(String userName)
        {
            User user = new User()
            {
                UserName = userName
            };
            _createUserService.CreateUser(user);
        }

        public void CreateMovie(String movieName, int release, String genre)
        {
            
            Movie movie = new Movie
            {
                MovieName = movieName,
                Genre = genre,
                Year = release
            };
            _movieService.CreateMovies(movie);
        }

        public void AddReview(String userName, String movieName, int rating)
        {
            MovieReview movieReview = new MovieReview
            {
                UserName = userName,
                Rating = rating
            };
            _movieService.Addreview(movieName, movieReview);
        }

        public void GetTopMovies(String genre, int limit)
        {
            _movieService.GetTopMoviesByCritic(genre, limit);
        }

        public void GetAverageScoreByYear(String movieName, int year)
        {
            Console.WriteLine("\nAverage Review Score for the movie :- " + movieName+" "+ "for the year - "+ year+ " :::: " +_movieService.GetAverageByYear(movieName, year).ToString());
        }

        public void GetAverageScore(String movieName)
        {
            Console.WriteLine("\nAverage Review Score for the movie :- " + movieName + " :::: " + _movieService.GetAverage(movieName).ToString());
        }
    }
}