﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Logger
{
    public class ExceptionLog
    {
        public static void Log(Exception ex)
        {
            Console.WriteLine("\n" + ex.Message);
        }
    }
}
