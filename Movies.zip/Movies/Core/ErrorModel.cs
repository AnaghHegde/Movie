﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Logger
{
    class ErrorModel
    {
        private readonly string defaultExceptionType = "GenericException";

        public string Exception { get; set; }
        public string ExceptionType { get; set; }

        public ErrorModel(Exception ex)
        {
            Exception = ex.Message;
            ExceptionType = SetExceptionType(ex);
        }

        internal String SetExceptionType(Exception ex)
        {
            return defaultExceptionType;
        }
    }
}
