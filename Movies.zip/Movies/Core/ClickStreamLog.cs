﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Movies.Core
{
    public class ClickStreamLog
    {
        public static void DBQueryLog(String log)
        {
            Console.WriteLine(log);
        }
    }
}
